<?php
class tbl_product
{
    public $id;
    public $categoryId;
    public $ressellerId;
    public $userId;
    public $subject;
    public $description;
    public $keywords;
    public $meta;
    public $picName;
    public $priceBuy;
    public $priceSell;
    public $priceSelltmp;
    public $number;
    public $weight;
    public $size;
    public $type;
    public $active;
}