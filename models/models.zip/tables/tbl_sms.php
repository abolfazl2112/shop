<?php
class tbl_sms
{
    public $id;
    public $name;
    public $username;
    public $password;
    public $number;
    public $active;
}