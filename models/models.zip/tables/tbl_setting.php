<?php
class tbl_setting
{
    public $id;
    public $name;
    public $discription;
    public $keywords;
    public $meta;
    public $currency;
    public $address;
    public $mobile;
    public $tell;
    public $logo;
    public $telegram;
    public $instagram;
    public $email;
    public $active;
}