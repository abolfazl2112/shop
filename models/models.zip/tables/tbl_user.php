<?php
class tbl_user
{
    public $id;
    public $name;
    public $family;
    public $father;
    public $mobile;
    public $birthdate;
    public $address;
    public $username;
    public $password;
    public $usertype;
    public $sex;
    public $picture;
    public $credit;
    public $rate;
    public $files;
    public $date;
    public $time;
    public $moaref;
    public $admin;
    public $active;
}