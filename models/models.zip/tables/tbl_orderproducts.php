<?php
class tbl_orderproduct
{
    public $id;
    public $orderid;
    public $productid;
    public $subject;
    public $picName;
    public $priceBuy;
    public $priceSelltmp;
    public $priceSell;
    public $number;
    public $total;
}