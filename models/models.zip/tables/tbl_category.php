<?php
class tbl_category
{
    public $id;
    public $ressellerId;
    public $userId;
    public $parentid;
    public $subject;
    public $description;
    public $pic;
    public $active;
}