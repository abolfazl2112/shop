<?php
class tbl_usertype
{
    private $id;
    private $name;
    private $active;
    private $access_menu;
    private $user;
    private $resseller;
    private $admin;
}