<?php
class tbl_order
{
    public $orderid;
    public $ressellerid;
    public $userid;
    public $price;
    public $discountcode;
    public $pricewithdiscount;
    public $description;
    public $paymenttype;
    public $date;
    public $time;
    public $state;
}