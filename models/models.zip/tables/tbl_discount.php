<?php
class tbl_discount
{
    public $id;
    public $userid;
    public $subject;
    public $code;
    public $percent;
    public $date1;
    public $date2;
    public $number;
    public $active;
}