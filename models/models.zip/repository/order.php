<?php
abstract class orderStates
{
    const pending = 0;
    const confirm = 1;
    const completed = 2;
    const cancel = 3;
}
class order
{
    private $db;
    private $sql_select = "select * from tbl_order WHERE 1 ";
    private $sql_insert = "INSERT INTO `tbl_order`
                              ( `orderid`, `ressellerid`, `userid`, `price`, `discountcode`, `pricewithdiscount`, `description`, `date`, `time`, `state`) 
                           VALUES 
                              ( %s , %s , %s , %s , %s, %s , %s ,%s , %s , %s )";
    private $sql_update = "UPDATE `tbl_order` 
                           SET 
                              `orderid`=%s,
                              `ressellerid`=%s,
                              `userid`=%s,
                              `price`=%s, 
                              `discountcode`=%s, 
                              `pricewithdiscount`=%s, 
                              `description`=%s, 
                              `date`=%s, 
                              `time`=%s, 
                              `state`=%s
                           WHERE 1 ";
    private $sql_delete = "delete from tbl_order WHERE 1 ";

    function __construct()
    {
        $this->db = new Database();
    }

    function insert($tblorder)
    {
        $sql = sprintf($this->sql_insert,
            check($tblorder->orderid),
            check($tblorder->ressellerid),
            check($tblorder->userid),
            check($tblorder->price),
            check($tblorder->discountcode),
            check($tblorder->pricewithdiscount),
            check($tblorder->description),
            check($tblorder->date),
            check($tblorder->time),
            check($tblorder->state)
        );
        return $this->db->IUD($sql);
    }

    function delete($id)
    {
        $sql = sprintf($this->sql_delete.' and id = '.check($id));
        return $this->db->IUD($sql);
    }

    function getOrders($start=-1,$end=-1)
    {
        $sql = $this->sql_select;

        if($start >= 0 && $end>=0)
        {
            $limit = 'LIMIT '.$start.' , '.$end;
        }
        else
            $limit = '';
        return $this->db->searchAllObjects($sql.$limit,'tbl_order');
    }

    function getUserOrders($userId,$start=0,$end=0)
    {
        $sql = $this->sql_select;
        $limit = ($start>0&&$end>0&&$start>$end?" LIMIT ".$start.",".$end." ":"");
        return $this->db->searchAllObjects($sql.' and userid='.check($userId).$limit,'tbl_order');
    }

    function getOrder($id)
    {
        $sql = $this->sql_select.' and id = '.check($id);
        return $this->db->searchFirst($sql);
    }

    function getOrderObject($id)
    {
        $sql = $this->sql_select.' and id = '.check($id);
        return $this->db->searchFirstObject($sql,'tbl_order');
    }
}