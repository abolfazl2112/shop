<?php
function http()
{
    return "http://localhost:8/onlineshopping/";
}
function get_path()
{
    return $_SERVER['DOCUMENT_ROOT']."/onlineshopping";
}
function http_admin()
{
    return http()."adminpanel/";
}
function http_user()
{
    return http()."portal/";
}

?>